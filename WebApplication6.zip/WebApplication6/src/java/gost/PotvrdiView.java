/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gost;

import javax.faces.bean.ManagedBean;
/**
 *
 * @author tijana
 */
@ManagedBean
public class PotvrdiView {
    private String text1;

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }
    
    
}
