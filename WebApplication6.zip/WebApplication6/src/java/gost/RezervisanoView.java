package gost;


 
import java.util.Date;
import javax.faces.bean.ManagedBean;
 
@ManagedBean
public class RezervisanoView {
     
    private String text1="promeni ovde";

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

   
    
 
   
}