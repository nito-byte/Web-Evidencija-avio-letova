package manegedBean;
 
import javax.faces.bean.ManagedBean;
 
@ManagedBean
public class SelectOneView {
     
    private String pol;

    public String getPol() {
        return pol;
    }

    public void setPol(String pol) {
        this.pol = pol;
    }

 

    
 
   
}